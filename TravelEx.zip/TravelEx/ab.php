<!DOCTYPE html>
<?php
include 'db_conn.php';
$conn = OpenCon();
$sql = "SELECT session_uid FROM travel_ex.session";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);
$uid=$row['session_uid'];

?>
<html>
    
<!-- Mirrored from mannatthemes.com/annex/horizontal/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Oct 2018 13:27:20 GMT -->
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>TravelEx</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Mannatthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <link href="assets/plugins/morris/morris.css" rel="stylesheet">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
		<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button2 {
    background-color: #008CBA; 
    color: white; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: white;
    color: #008CBA;
}
.body{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background-image: url(assets/images/background.jpg);
	background-size: cover;
	-webkit-filter: blur(5px);
	z-index: 0;
}
body{
	margin: 0;
	padding: 0;
	background: #fff;
	color: #fff;
	font-family: verdana;
	font-size: 12px;
}
.grad{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0.65))); /* Chrome,Safari4+ */
	z-index: 1;
	opacity: 0.7;
}
</style>

    </head>


    <body >
	<div class="body"><input type="text"  size="15" name="destination"></div>
	<div class="grad"></div>
	

       


    </body>

<!-- Mirrored from mannatthemes.com/annex/horizontal/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Oct 2018 13:28:02 GMT -->
</html>