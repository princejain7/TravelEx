
<?php


function addition($uid) {
    $GLOBALS['z'] = $uid;
}


echo $GLOBALS['z'];
?>


