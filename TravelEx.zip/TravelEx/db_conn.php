<?php	


function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "pkg";
 $dbpass = "zX9XvY1pB9sTyM38";
 $db = "travel_ex";


 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);

 
 return $conn;
 }

function uid_catch($uid)
{
	$GLOBALS['uidi']=$uid;
	
	return $GLOBALS['uidi'];
	
	
	
}






function uid_return()
{
  return $GLOBALS['uidi'];
}	
function CloseCon($conn)
 {
 $conn -> close();
 }
   
   
 
?>