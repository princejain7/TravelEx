<?php
include 'db_conn.php';
$conn = OpenCon();

$source="Delhi";
$dest="Chandigarh";
$dte="11/20/2018";
$tme="16:00";
$tma=array();
$timestamp = time();
$tm=(string)$tme;


	$tma=explode(":",$tme);

	$h=$tma[0];
	$m=$tma[1];
if($h>12)
{
	$h=$h-12;
	$tm=$h.":".$m."PM";
	
}
else
{
	$tm=$h.":".$m."AM";
}


	

$cmd = 'python  ml-final.py "'.$source.'" "'.$dest.'" "'.$dte.'" "'.$tme.'"';


$sql = "SELECT session_uid FROM travel_ex.session";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);
$uid=$row['session_uid'];

$output="8:00AM";

$time_in_24_hour_format  = date("H:i", strtotime($output));
echo "time".$time_in_24_hour_format;
$tmp=(string)$tme;



$t1 = strtotime($tmp);
$t2 = strtotime($time_in_24_hour_format);

echo " t1".$t1;
echo " t2".$t2;
if($t2<$t1){echo "    c1    ";
$hours = ($t2 - $t1)/3600;}
else{echo "    c2    ";$hours = 24-(($t2 - $t1)/3600);}
echo "   hours".$hours;
if($hours<0)
{
	$hours=(-1)*$hours;
}

$diff=floor($hours) . ':' . ( ($hours-floor($hours)) * 60 );
echo " diff".$diff;

$sql_1="INSERT INTO `history` (`source`, `desination`, `date`, `reach_time`, `pred_time`, `uid`,`difference`) VALUES ('$source', '$dest', '$dte', '$tm', '$output', '$uid','$diff')";
mysqli_query($conn,$sql_1);

echo "dne";



//echo $cmd;

?>