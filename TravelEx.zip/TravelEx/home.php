<!DOCTYPE html>
<?php
include 'db_conn.php';
$conn = OpenCon();
$sql = "SELECT session_uid FROM travel_ex.session";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);
$uid=$row['session_uid'];

?>
<html>
    

<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>TravelEx</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Mannatthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="assets/images/fav.ico">

        <link href="assets/plugins/morris/morris.css" rel="stylesheet">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
		<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button2 {
    background-color: #008CBA; 
    color: white; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: white;
    color: #008CBA;
}

.body{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background-image: url(assets/images/background-cropped.jpg);
	background-size: cover;
	-webkit-filter: blur(5px);
	z-index: 0;
}
body{
	margin: 0;
	padding: 0;
	background: #fff;
	color: #fff;
	font-family: verdana;
	font-size: 12px;
}
.grad{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0.65))); /* Chrome,Safari4+ */
	z-index: 1;
	opacity: 0.7;
}
</style>

    </head>


    <body >
	
	<div class="body"></div>
	
	

        <!-- Loader -->
        <div id="preloader"><div id="status"><div class="spinner"></div></div></div>

        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo container-->
                    <div class="logo">
                        <!-- Text Logo -->
                        <!--<a href="index.html" class="logo">-->
                        <!--Annex-->
                        <!--</a>-->
                        <!-- Image Logo -->
                        <a href="index.html" class="logo">
                            
                            <img src="assets/images/logo.png" alt="" height="88" class="logo-large">
                        </a>

                    </div>
                    <!-- End Logo container-->


                    <div class="menu-extras topbar-custom">

                        <ul class="list-inline float-right mb-0">
                            
                            <!-- language-->
                            <li class="list-inline-item dropdown notification-list hide-phone">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button"
                                    aria-haspopup="false" aria-expanded="false">
                                    India <img src="assets/images/flags/indian_flag.png" class="ml-2" height="16" alt=""/>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right language-switch">
                                    <a class="dropdown-item" href="#"><img src="assets/images/flags/italy_flag.jpg" alt="" height="16"/><span> Italy </span></a>
                                    <a class="dropdown-item" href="#"><img src="assets/images/flags/french_flag.jpg" alt="" height="16"/><span> France</span></a>
                                    <a class="dropdown-item" href="#"><img src="assets/images/flags/spain_flag.jpg" alt="" height="16"/><span> Spain  </span></a>
                                    <a class="dropdown-item" href="#"><img src="assets/images/flags/russia_flag.jpg" alt="" height="16"/><span> Russia </span></a>
                                </div>
                            </li>

                            
                            <!-- User-->
                            <li class="list-inline-item dropdown notification-list">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                                   aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/avatar-1.png" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <div class="dropdown-item noti-title">
                                        <h5>Welcome</h5>
                                    </div>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle m-r-5 text-muted"></i> Profile</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5 text-muted"></i> My Wallet</a>
                                    <a class="dropdown-item" href="#"><span class="badge badge-success float-right">5</span><i class="mdi mdi-settings m-r-5 text-muted"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5 text-muted"></i> Lock screen</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="logout.php"><i class="mdi mdi-logout m-r-5 text-muted"></i> Logout</a>
                                </div>
                            </li>
                            <li class="menu-item list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>
                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <!-- MENU Start -->
            <div class="navbar-custom">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="home.php"><i class="mdi mdi-airplay"></i>Home</a>
                            </li>

                            <li class="has-submenu">
                                <a href="map-page.php"><i class="mdi mdi-layers"></i>Map</a>
                                
                            </li>

                            <li class="has-submenu">
                                <a href="history.php"><i class="mdi mdi-bullseye"></i>History</a>
                                
                            </li>

                           

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end #navigation -->
                </div> <!-- end container -->
            </div> <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->


        <div class="wrapper">
            <div class="container-fluid">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                           
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->
				<form action="pg-1.php" method="get">
                <div class="row">
				
                    <!-- Column -->
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <div class="d-flex flex-row">
                                    <div class="col-3 align-self-center">
                                        <div class="round">
                                            <i class="mdi mdi-webcam"></i>
                                        </div>
                                    </div>
                                    <div class="col-6 align-self-center text-center">
                                        <div class="m-l-10">
                                            <input type="text"  size="15" name="Source">
                                            <p class="mb-0 text-muted">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Source</p>                                                                 
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
				
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <div class="d-flex flex-row">
                                    <div class="col-3 align-self-center">
                                        <div class="round">
                                            <i class="mdi mdi-account-multiple-plus"></i>
                                        </div>
                                    </div>
                                    <div class="col-6 text-center align-self-center">
                                        <div class="m-l-10 ">
                                            <input type="text"  size="15" name="destination">
                                            <p class="mb-0 text-muted">&nbsp;&nbsp;&nbsp;Where to go?</p>
                                        </div>
                                    </div>
                                                                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <div class="d-flex flex-row">
                                    <div class="col-3 align-self-center">
                                        <div class="round ">
                                            <i class="mdi mdi-basket"></i>
                                        </div>
                                    </div>
                                    <div class="col-6 align-self-center text-center">
                                        <div class="m-l-10 ">
                                            <input type="date" class="mt-0 round-inner" size="15" name="date">
                                            <p class="mb-0 text-muted">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date</p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-md-6 col-lg-6 col-xl-3">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <div class="d-flex flex-row">
                                    <div class="col-3 align-self-center">
                                        <div class="round">
                                            <i class="mdi mdi-rocket"></i>
                                        </div>
                                    </div>
                                    <div class="col-6 align-self-center text-center">
                                        <div class="m-l-10">
                                           <input type="time" class="mt-0 round-inner" size="15" name="time">
                                            <p class="mb-0 text-muted">Time to Reach</p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
				
				<div class="row">
				<div class="col-md-6 col-lg-6 col-xl-5">
				</div>
				<div class="col-md-6 col-lg-6 col-xl-2">
				<input type="submit" class="button button2" align="center" value="Submit">
				</div>
				<div class="col-md-6 col-lg-6 col-xl-5">
				</div>
				</div>
				<form>

                <div class="row">
                    
                    <div class="col-md-12 col-lg-6 col-xl-4">
                        <div class="card bg-info m-b-30">
                            <div class="card-body">
                                <div id="verticalCarousel" class="carousel slide vertical" data-ride="carousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <div class="row d-flex justify-content-center text-center">
                                                <div class="col-sm-12 carousel-icon">
                                                    <i class="fa fa-twitter text-white pt-3"></i>
                                                </div>
                                                <div class="col-6 text-white">                                                                
                                                    <h2>54k</h2>
                                                    <p class="">Followers</p>                                                                
                                                </div>
                                                <div class="col-6 text-white">                                                                
                                                    <h2>44k</h2>
                                                    <p class="">Tweets</p>                                                               
                                                </div>
                                            </div>
                                        </div>

                                        <div class="carousel-item">
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-sm-12 carousel-icon text-center">
                                                    <i class="fa fa-twitter text-white pt-3"></i>
                                                </div>
                                                <div class="col-sm-10 mx-auto text-white text-center">
                                                    <p>Lorem Ipsum is simply dummy text of the <span class="warning">#TWITTER</span> and typesetting industry. A description list is perfect for defining terms.</p>
                                                </div>
                                            </div>
                                        </div>                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card bg-primary ">
                            <div class="card-body">
                                <div id="verticalCarousel2" class="carousel slide" data-ride="carousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-lg-12 carousel-icon text-center">
                                                    <i class="fa fa-facebook text-white pt-3"></i>
                                                </div>
                                                <div class="col-sm-10 mx-auto text-white text-center">
                                                    <p>Lorem Ipsum is simply dummy text of the <mark> FACEBOOK </mark> and typesetting industry.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <div class="row d-flex justify-content-center text-white text-center">
                                                <div class="col-sm-12 carousel-icon">
                                                    <i class="fa fa-facebook text-white pt-3"></i>
                                                </div>
                                                <div class="col-6">                                                                
                                                    <h2>54k</h2>
                                                    <p class="">Followers</p>                                                               
                                                </div>
                                                <div class="col-6">                                                                
                                                    <h2>44k</h2>
                                                    <p class="">Posts</p>                                                                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-6 col-xl-4">
                        <div class="card bg-info m-b-30">
                            <div id="verticalCarousel2" class="carousel slide card-body new-user" data-ride="carousel">
							<div  style="height: 310px">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <div class="row d-flex justify-content-center">
                                                
                                                <div class="col-sm-10 mx-auto text-white text-center">
                                                     <h3>“It is not down in any map; true places never are.” – Herman Melville</h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <div class="row d-flex justify-content-center text-white text-center">
                                                
                                                <div class="col-6">                                                                
                                                    <h3>“Man cannot discover new oceans unless he has the courage to lose sight of the shore.” – Andre Gide</h3>
                                                                                                                    
                                                </div>
                                            </div>
                                        </div>
										
                                    </div>
							</div>
									
                            </div>
							<div  style="height: 310px"></div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-12 col-xl-4">
                        <div class="card bg-white m-b-30">
                            <img src="assets/images/widgets/wather.jpg" alt="" class="img-fluid">
                            
                            <div class="card-body bg-primary">                                
                                <div class="row">
                                    <div class="col-6  align-self-center">
                                        <div class="row">
                                            <div class="col-lg-6 col-sm-6 text-center">
                                                <canvas id="partly-cloudy-day" width="70" height="70"></canvas>
                                                <h6 class="text-white">MON <span>19<sup>th</sup></span></h6>
                                            </div>
                                            <div class="col-lg-6 col-sm-6 text-center align-self-center">
                                                <h5 class="mt-0 text-white"><b>24°</b></h5>
                                                <p class="text-white  font-12">Hazy Sunshine</p>
                                                <p class="text-white font-12">11.7km/h - 52%</p>
                                            </div>
                                        </div><!-- End row -->
                                    </div>
                                    <div class="col-6 align-self-center">
                                        <div class="row">
                                            <div class="col-6 text-center">
                                                <h6 class="text-white mt-0 font-14">TUE</h6>
                                                <canvas id="cloudy" width="28" height="35"></canvas>
                                                <h6 class="text-white font-14">29°<i class="wi-degrees"></i></h6>
                                            </div>
                                            <div class="col-6 text-center">
                                                <h6 class="text-white mt-0 font-14">WED</h6>
                                                <canvas id="wind" width="35" height="35"></canvas>
                                                <h6 class="text-white font-14">28°<i class="wi-degrees"></i></h6>
                                            </div>                                                                                                                                              
                                        </div><!-- end row -->
                                    </div>
                                </div><!-- end row -->                            
                            </div>
                        </div>
                    </div>                                                 
                </div>
                

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- Footer -->
        <footer class="footer">
            <div class="container-fluid body"></div>
                <div class="row">
                    <div class="col-12">
                        © Copyright. All rights reserved
                    </div>
                </div>
            
        </footer>
        <!-- End Footer -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <!--<script src="assets/js/bootstrap.min.js"></script>-->
        <script src="assets/js/modernizr.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <script src="assets/plugins/skycons/skycons.min.js"></script>
        <script src="assets/plugins/raphael/raphael-min.js"></script>
        <script src="assets/plugins/morris/morris.min.js"></script>
        
        <script src="assets/pages/dashborad.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script>
            /* BEGIN SVG WEATHER ICON */
            if (typeof Skycons !== 'undefined'){
           var icons = new Skycons(
               {"color": "#fff"},
               {"resizeClear": true}
               ),
                   list  = [
                       "clear-day", "clear-night", "partly-cloudy-day",
                       "partly-cloudy-night", "cloudy", "rain", "sleet", "snow", "wind",
                       "fog"
                   ],
                   i;

               for(i = list.length; i--; )
               icons.set(list[i], list[i]);
               icons.play();
           };

       // scroll

       $(document).ready(function() {
       
       $("#boxscroll").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true});
       $("#boxscroll2").niceScroll({cursorborder:"",cursorcolor:"#cecece",boxzoom:true}); 
       
       });
       </script>



    </body>

</html>