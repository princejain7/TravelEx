<?php

?>


<html lang="en">
<head>
  <title>log in Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="boot.css">
  <link rel="stylesheet" type="text/css" href="boot1.css">
  <link rel="shortcut icon" href="assets/images/fav.ico">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  <script src="dctr.js" type="text/javascript"></script>
</head>

<body style="height:100%; margin:0px; overflow-y: hidden;">
<div>
<!-- =============================nav-bar===========================================	 -->
		<div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top" style="height: 80px;box-shadow: 0px -1px 14px #eee">
  <a class="navbar-brand" href="#" style="font-size: 34px;"><img src="assets/images/logo-home.png" height="60px" margin="0px"></a>
  <button class="submit-btn btn-primary btn" style="width: 87px;margin-left: 950px;margin-top: 3px;">SIGN UP</button>
</nav>
   </div>
<br>
<br>
<div class="form">
    <form action="login.php" method="POST">
    	<div class="form1">
    		<input class="form-control" id="Username" name="Username" placeholder="Username" style="width: 370px;height: 38px;margin-left: 39px;" type="text" required>
    		<input class="form-control" id="Password" name="Password" placeholder="Password" style="margin-top: 24px;width: 370px;height: 38px;margin-left: 39px;" type="password" required>
    		<input class="submit-btn btn-primary btn" style="width: 87px;margin-left: 170px;margin-top: 27px; height: 43px; background-color: rgb(52,58,64);" value="LOG IN" type="submit">
    		<div style="margin-left: 266px;margin-top: -33px;">
    		    <a href="#" class="forgot">Forgot your password?</a>
    		</div>
    </div>  	
    </form>
</div>
<!-- ==============================footer==================================== -->
<div class="footer">
	<h5>© Copyright. All rights reserved</h5>
	<p  id="face" ><a href="https://www.facebook.com/jacksonhealthcare/" style="color:black;" target="_blank"><i style="font-size:24px" class="fa">&#xf09a;</i></a>
		&nbsp;&nbsp;
		<a href="" style="color:black;"><i style="font-size:24px" class="fa" target="_blank">&#xf099;</i></a>
		&nbsp;&nbsp;
		<a href="" style="color:black;"><i style="font-size:24px" class="fa" target="_blank">&#xf16a;</i></a></p>
</div>
<!-- ======================================================================= -->
</div>
</body>
</html>


