<?php
 include 'db_conn.php';

$conn = OpenCon();
   session_start();
   $error="";
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($conn,$_POST['Username']);
      $mypassword = mysqli_real_escape_string($conn,$_POST['Password']); 
	  
      if(!empty($mypassword))
	{
      $sql = "SELECT * FROM travel_ex.user_cred where user_id = '$myusername' and passwd = '$mypassword'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result);
	  
      $count = mysqli_num_rows($result);
	  
	  
	  
	  
   
             $uid=$row["uid"];
			 
			 $uid=uid_catch($uid);
			 $uid=uid_return();
		     echo $uid;
			 
			 $sql_S="UPDATE `session` SET `session_uid`=$uid";
			 mysqli_query($conn,$sql_S);
			 
        
		
		
		
       
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
		 
         header("location:home.php");
      }else {
         $_SESSION['error'] = "Your Login Name or Password is invalid";
		 
		 //header("location: index.php");
		 
      }
    }
	else{
		$_SESSION['error'] = "Your Login Name or Password is invalid";
		
		header("location: index.php");
	}
      
   }
?> 
