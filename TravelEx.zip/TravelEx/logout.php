<?php
   include 'db_conn.php';
$conn = OpenCon();
   session_start();
   $sql_S="UPDATE `session` SET `session_uid`=0";
   mysqli_query($conn,$sql_S);
   
   if(session_destroy()) {
      header("Location: index.php");
   }
?>