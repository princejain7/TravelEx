<!DOCTYPE html>
<html lang="en">

<?php
include 'db_conn.php';
$conn = OpenCon();

?>

<head>
	<style type="text/css" media="screen">
		div{
			float: left;
			margin-left:  5%;
		}
	</style>
<body>
<br>

<form action="submit.php" method="GET">
    
	<div>
    	Date
		<br>
		<input type="date" name="Date" required>
	</div>
	<div> 
	    Time
	    <br>
	    <input type="time" name="Time" required>
		<br>
		<br>
	<button type="submit">Submit</button>
	</div>
	<div>
	     Source
		 <br>
		 <input type="text" placeholder="Enter Your Location" name="source" required>
	</div>
	<div>
	     Destination
		 <br>
		 <input type="text" placeholder="Enter Your Destination" name="destination" required>
	</div>
	
  </form> 

</body>
</head>
</html>