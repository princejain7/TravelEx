<?php 
include 'db_conn.php';
$conn = OpenCon();

$date = mysqli_real_escape_string($conn,$_GET['Date']);
$time = mysqli_real_escape_string($conn,$_GET['Time']); 
$source = mysqli_real_escape_string($conn,$_GET['source']);
$dest = mysqli_real_escape_string($conn,$_GET['destination']); 



$time = strtotime($date);

$date = date('d-m-Y',$time);


$dt = strtotime($date);
$day = date("D", $dt);


	 
/*
$urls="https://apis.mapmyindia.com/advancedmaps/v1/uiacpp2ly7t2yqroaegm1prshruqy4ls/geo_code?addr=".$source;
$urld="https://apis.mapmyindia.com/advancedmaps/v1/uiacpp2ly7t2yqroaegm1prshruqy4ls/geo_code?addr=".$dest;

$response  = file_get_contents($urls);
$jsonobj  = json_decode($response);
$lat_s=$jsonobj->results[0]->lat;
$lon_s=$jsonobj->results[0]->lng; 	

$response  = file_get_contents($urld);
$jsonobj  = json_decode($response);
$lat_d=$jsonobj->results[0]->lat;
$lon_d=$jsonobj->results[0]->lng; */

$in_query="INSERT INTO `INPUTS` VALUES `".$date."`,`".$time."`,`".$day.",".$lat_s.",".$long_s.",".$lat_d.",".$long_d.",`".$source."`,`".$dest."`";
//$conn->query($in_query);


/*
var request = new XMLHttpRequest();

request.open('GET', $urls, true);
request.onload = function () {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response);

  if (request.status >= 200 && request.status < 400) {
    data.forEach(result=> {
      console.log(result.lat);
	  console.log(result.lng);
    });
  } else {
    console.log('error');
  }
}

request.send();*/
?>