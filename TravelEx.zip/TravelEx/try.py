import xlsxwriter
import urllib2
import json
import datetime
import time



def lat_lon_calc(addr):
	url="https://maps.googleapis.com/maps/api/geocode/json?address="+addr+"&key=AIzaSyCTHwCnl_VrqowvDPFeEzQXgobof1jR4aM"
	print(url)
	json_file=urllib2.urlopen(url)
	data=json.load(json_file)
	lat_lng=[]
	

	print(data['results'][0]['geometry']['location']['lat'])
	print(data['results'][0]['geometry']['location']['lng'])
	


lat_lon_calc('JAYPEE+INSTITUTE+OF+INFORMATION+TECHNOLOGY+A+10+SEC+62,+Ghaziabad,+Uttar+Pradesh+201309+')